### [RunJS](https://runjs.app)

#### Activating theme

1. Open the [RunJS](https://runjs.app) app.
2. Click on `Preferences` in the app menu.
3. Navigate to the `Appearance` tab within the `Preferences` window.
4. Select the theme.