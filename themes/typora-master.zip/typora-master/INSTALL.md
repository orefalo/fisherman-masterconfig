### [Typora](https://typora.io/)

#### Install

Download using the [GitHub .zip download](https://github.com/dracula/typora/archive/master.zip) option

1. Open Theme Folder. (see instructions below)
1. Copy or move .css file and related resources, like fonts or images, into the newly opened folder.
1. Restart Typora, then select it from Themes menu.