# Changes

- Fixed background of Math blocks to a dark color.

- Switched fixed-width font of source and math blocks to Fira Code.

![math-example](https://i.imgur.com/q36Q1GI.png)


